// src/layouts/UserLayout.jsx
import { Outlet } from 'react-router-dom';
import { ThemeProvider } from '@context/ThemeContext';
import MainHeader from '@layouts/user/headers/MainHeader';
import MainFooter from '@layouts/user/footers/MainFooter';

const UserLayout = () => {
  return (
    <ThemeProvider>
      <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
        {/* 헤더 */}
        <MainHeader />

        {/* 콘텐츠 */}
        <main style={{ flex: 1 }}>
          <Outlet />
        </main>

        {/* 푸터 */}
        <MainFooter />
      </div>
    </ThemeProvider>
  );
};

export default UserLayout;

D:\PROJECT\nct-frontend\nct-frontend\nct-frontend\src\layouts\user\footers
