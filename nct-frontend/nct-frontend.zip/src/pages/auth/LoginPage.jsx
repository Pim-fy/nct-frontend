// src/pages/auth/LoginPage.jsx
import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Eye, EyeOff } from 'lucide-react';
import { useAuth } from '@hooks/useAuth';

// ── 소셜 로그인 버튼 데이터 ──────────────────────────────
const SOCIAL_PROVIDERS = [
  {
    key     : 'kakao',
    label   : '카카오',
    bg      : '#FEE500',
    color   : '#181600',
    href    : () => `${import.meta.env.VITE_API_URL}/api/oauth2/authorization/kakao`,
    icon    : (
      <svg viewBox="0 0 24 24" width="26" height="26" fill="currentColor">
        <path d="M12 3C6.48 3 2 6.48 2 10.8c0 2.7 1.6 5.1 4 6.6l-1 3.6 4.2-2.8c.9.2 1.8.3 2.8.3 5.52 0 10-3.48 10-7.7S17.52 3 12 3z"/>
      </svg>
    ),
  },
  {
    key     : 'naver',
    label   : '네이버',
    bg      : '#03C75A',
    color   : '#fff',
    href    : () => `${import.meta.env.VITE_API_URL}/api/oauth2/authorization/naver`,
    icon    : (
      <span style={{ fontWeight: 900, fontSize: '18px', lineHeight: 1 }}>N</span>
    ),
  },
  {
    key     : 'google',
    label   : '구글',
    bg      : '#fff',
    color   : '#444',
    border  : '1.5px solid #e2e2e2',
    href    : () => `${import.meta.env.VITE_API_URL}/api/oauth2/authorization/google`,
    icon    : (
      <svg viewBox="0 0 24 24" width="22" height="22">
        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
      </svg>
    ),
  },
];

// ── LoginPage ─────────────────────────────────────────────
export default function LoginPage() {
  const navigate  = useNavigate();
  const location  = useLocation();
  const { login } = useAuth();

  // 로그인 성공 후 돌아갈 경로
  const from = location.state?.from?.pathname
    || sessionStorage.getItem('loginRedirectFrom')
    || '/';

  const [userId,       setUserId]       = useState('');
  const [password,     setPassword]     = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe,   setRememberMe]   = useState(false);
  const [loading,      setLoading]      = useState(false);

  // ── 일반 로그인 ───────────────────────────────────────
  const handleLogin = async () => {
    if (!userId.trim() || !password.trim()) {
      alert('아이디와 비밀번호를 입력해주세요.');
      return;
    }

    setLoading(true);
    try {
      const payload  = { email: userId, password: password, rememberMe };
      const userData = await login(payload);

      sessionStorage.removeItem('loginRedirectFrom');

      if (userData?.role === 'ROLE_ADMIN') {
        navigate('/admin', { replace: true });
      } else {
        const safePath = from.startsWith('/admin') ? '/' : from;
        navigate(safePath, { replace: true });
      }
    } catch (error) {
      if (error.response?.status === 401) {
        alert('아이디 또는 비밀번호가 일치하지 않습니다.');
      } else if (error.response?.data?.message) {
        alert(error.response.data.message);
      } else {
        alert('로그인 처리 중 오류가 발생했습니다.');
      }
    } finally {
      setLoading(false);
    }
  };

  // Enter 키 로그인
  const handleKeyDown = (e) => {
    if (e.key === 'Enter') handleLogin();
  };

  // ── 소셜 로그인 ───────────────────────────────────────
  const handleSocialLogin = (provider) => {
    window.location.href = provider.href();
  };

  // ── 렌더 ─────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-[440px] bg-white rounded-2xl shadow-lg px-8 py-10">

        {/* 로고 */}
        <div className="text-center mb-8">
          <Link to="/">
            <h1 className="text-4xl font-extrabold text-blue-600 tracking-tight">
              Ksteam
            </h1>
          </Link>
        </div>

        {/* 입력 폼 */}
        <div className="flex flex-col gap-4">

          {/* 아이디 */}
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium text-gray-700">아이디</label>
            <input
              type="text"
              placeholder="ksmart01"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              onKeyDown={handleKeyDown}
              className="
                w-full h-12 px-4 rounded-lg border border-gray-300
                text-sm text-gray-900 placeholder-gray-400
                outline-none transition
                focus:border-blue-500 focus:ring-2 focus:ring-blue-100
              "
            />
          </div>

          {/* 비밀번호 */}
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium text-gray-700">비밀번호</label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder="비밀번호"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={handleKeyDown}
                className="
                  w-full h-12 px-4 pr-11 rounded-lg border border-gray-300
                  text-sm text-gray-900 placeholder-gray-400
                  outline-none transition
                  focus:border-blue-500 focus:ring-2 focus:ring-blue-100
                "
              />
              <button
                type="button"
                onClick={() => setShowPassword((p) => !p)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition cursor-pointer"
                aria-label={showPassword ? '비밀번호 숨기기' : '비밀번호 보기'}
              >
                {showPassword
                  ? <EyeOff size={18} />
                  : <Eye size={18} />
                }
              </button>
            </div>
          </div>

          {/* 하루동안 로그인 유지 */}
          <label className="flex items-center gap-2 cursor-pointer select-none w-fit">
            <input
              type="checkbox"
              checked={rememberMe}
              onChange={(e) => setRememberMe(e.target.checked)}
              className="w-4 h-4 rounded border-gray-300 accent-blue-600 cursor-pointer"
            />
            <span className="text-sm text-gray-500">하루동안 로그인 유지</span>
          </label>

          {/* 로그인 버튼 */}
          <button
            type="button"
            onClick={handleLogin}
            disabled={loading}
            className="
              mt-1 w-full h-12 rounded-lg
              bg-blue-600 hover:bg-blue-700 active:scale-[0.98]
              text-white text-base font-bold
              transition-all duration-150 cursor-pointer
              disabled:opacity-60 disabled:cursor-not-allowed
            "
          >
            {loading ? '로그인 중...' : '로그인'}
          </button>
        </div>

        {/* 회원가입 | 아이디 찾기 | 비밀번호 찾기 */}
        <div className="flex items-center justify-between mt-5 text-sm">
          <Link
            to="/login/signup"
            className="font-semibold text-gray-700 hover:text-blue-600 transition [text-decoration:underline] underline-offset-2"
          >
            회원가입 →
          </Link>
          <div className="flex items-center gap-2 text-gray-500">
            <Link to="/find-email"      className="hover:text-blue-600 transition">아이디 찾기</Link>
            <span className="text-gray-300">|</span>
            <Link to="/reset-password"  className="hover:text-blue-600 transition">비밀번호 찾기</Link>
          </div>
        </div>

        {/* 소셜 로그인 */}
        <div className="mt-7">
          <div className="flex items-center justify-center gap-6">
            {SOCIAL_PROVIDERS.map((provider) => (
              <div key={provider.key} className="flex flex-col items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleSocialLogin(provider)}
                  className="
                    w-14 h-14 rounded-full flex items-center justify-center
                    shadow-sm hover:brightness-95 active:scale-95
                    transition-all duration-150 cursor-pointer
                  "
                  style={{
                    background : provider.bg,
                    color      : provider.color,
                    border     : provider.border ?? 'none',
                  }}
                  aria-label={`${provider.label} 로그인`}
                >
                  {provider.icon}
                </button>
                <span className="text-xs text-gray-500 font-medium">
                  {provider.label}
                </span>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}